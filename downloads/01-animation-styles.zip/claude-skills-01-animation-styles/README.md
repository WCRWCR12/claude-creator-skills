# Animation Styles pack (8 free Claude skills)

Make the animations from the reels: 100+ coded animation styles (paper cut-out, clay, pixel art, chalk, neon and more), your logo animated, motion-graphics reels with a self-critique loop.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `animation-styles` | A library of 123 named, coded animation and motion-graphic styles (paper cut-out, brick toy, pixel art, chalkboard, neon, watercolour, woodcut,… |
| `animation-ground-truth` | A house animation style for motion graphics and faceless reels. |
| `motion-graphics-render-loop` | Make premium coded motion-graphics reels (spring physics, real UI assets, cuts locked to a beat) with Remotion, plus a self-critique loop that hunts… |
| `logo-animation` | Animates a logo in code, no After Effects: it draws the logo in lines, explodes it into parts, and snaps it back together in about four seconds,… |
| `numbered-technique-showcase-reel` | A reel format for demonstrating a set of related skills or techniques. |
| `one-to-one-style` | Copy a reference reel's animation style at a chosen fidelity (exact re-shoot, style match, or pattern match). |
| `pixel-narrator` | Build a coded pixel-art narrator character in Remotion, a Stardew-style game portrait that pops up in the corner of a reel, lip-syncs to the… |
| `video-contact-sheet` | Cut the token cost of reading a video. |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
