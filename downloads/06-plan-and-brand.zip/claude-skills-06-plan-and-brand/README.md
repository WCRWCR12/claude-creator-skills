# Plan and Brand pack (10 free Claude skills)

A month of posts in one sitting, content pillars, your brand voice, your audience's own words, trends worth jumping on, carousels and image prompts.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `batch-content-plan` | a week or a month — in one session: strategically balanced, on-brand, mapped to a calendar, and ready to schedule. |
| `content-calendar` | a sustainable, repeatable posting rhythm and recurring structure (which pillars/formats post on which days, on which platforms), derived from… |
| `content-pillars` | the 3–5 recurring themes it posts about — the strategic backbone between the brand profile and the content calendar. |
| `social-strategy` | which channels to focus on (and which to ignore), what to achieve, the angle to win, and a realistic operating cadence. |
| `brand-profile` | Use FIRST, before any other social media skill, to load or create the brand profile — the durable record of who a business is, who it serves, how it… |
| `voice-builder` | Use to build a reusable voice guide (voice.md) by analyzing a person's or brand's ACTUAL writing samples — so every other social skill can write in… |
| `audience-research` | sharp enough that every content skill resonates with them specifically. |
| `trend-jacking` | a trending sound, format, meme, hashtag, news moment, or cultural conversation — to earn reach by attaching the brand to something already getting… |
| `image-prompt` | Use as the foundation and router for any image a post needs — turn a social need into a clear image brief, describe it with model-agnostic prompt… |
| `auto-carousel` | A pipeline for producing on-brand Instagram carousels where you only approve topics and final slides. |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
