# Captions and Growth pack (8 free Claude skills)

Captions Instagram and TikTok search can find, hashtags, profile fixes, clipping long videos, and a daily engagement routine.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `caption-writer` | the words that accompany a post on Instagram, LinkedIn, TikTok, Facebook, X/Twitter, Threads, Pinterest, YouTube, or Bluesky. |
| `social-seo` | the social-SEO / keyword-discovery skill. |
| `captions-and-clipping` | The long-form-to-Shorts + sound-off captions mini-skill (Opus Clip / CapCut / Submagic). |
| `hashtag-strategy` | the modern (2026) approach, not the outdated "30 hashtags to go viral" playbook. |
| `instagram-growth` | the Instagram-specific growth strategy that diagnoses where growth is stuck (reach, follow-conversion, retention, or shares) and orchestrates the… |
| `tiktok-growth` | the TikTok-specific growth strategy that diagnoses where growth is stuck and orchestrates the other skills to fix it. |
| `profile-optimization` | bio, handle, name/headline field, profile picture, banner/header, link-in-bio, CTA, pinned posts, and highlights. |
| `engagement-routine` | the operating system that turns the engagement craft into a daily/weekly habit. |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
