# SEO and Getting Clients pack (9 free Claude skills)

Rank on Google and in AI search, get listed, turn a viral video into a page, and run outreach and ads that bring in clients.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `rank-fast-seo-article` | Write a search-targeted article by scraping what already ranks on page 1, adding the founder's own point of view, and checking the ranking. |
| `parasite-seo` | Rank for buyer-intent searches by publishing useful pages on sites Google and AI assistants already trust (Zenodo, LinkedIn, Gamma, Reddit, listicle… |
| `local-citations-listings` | Build or audit free local business citations, listings and entity profiles (Google Business Profile, Bing, Apple, directories, trade marketplaces,… |
| `founder-about-page-seo` | Audit or write a small business's About page, statistics/original-research page and footer links to improve search and AI-answer visibility. |
| `meta-muse-content-research` | Plan Instagram content using trend, niche-creator and own-account insight. |
| `viral-reel-to-page` | Turn a viral "look what AI does for my business" social reel into an indexable landing page that catches the Google and AI-assistant searches the… |
| `cold-email-infrastructure` | Plan, size and run a compliant cold email system for a small business: sending domains and inboxes, DNS (SPF/DKIM/DMARC), warmup, deliverability… |
| `google-ads-offer-led-playbook` | Offer-led Google Ads playbook for local and B2B small businesses. |
| `website-revamp-outreach` | Find local businesses with weak websites, build a template-based mock revamp, and draft a compliant enquiry message for you to review and send… |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
