# Reel Formats and Research pack (8 free Claude skills)

Proven reel formats beat by beat, a house reel style, film-director shot plans, and tools to study any video or rival cheaply.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `reel-formats-library` | A library of proven short-form reel and ad formats, broken down beat by beat with timings, pacing, caption style and how to remake each for a brand… |
| `reel-style` | A complete house style for face-to-camera tech/tool explainer reels - a title-card hook, a face-to-camera base layer, full-frame… |
| `cinematic-director` | Acts as a director and previs supervisor for film, video, and AI filmmaking. |
| `hook-flip-reel-scout` | Find and verify reference short videos for the "hook then hard flip to product" ad format (a raw fail, funny or odd moment of 2-6 s, then slick… |
| `real-screenshots-value-led` | A reel format built on genuine UI screenshots and real tool, app or data visuals to deliver value-led content. |
| `viral-reverse-engineering` | yours or someone else's — and extract the repeatable mechanism to apply to your own content. |
| `bot-series-workflow` | Split a reel and caption pipeline into a series of single-purpose agents (research, pattern, script, edit, critic, caption), each with one input,… |
| `competitor-analysis` | Competitor analysis for social media — public-data competitive reconnaissance to find the gap a brand can own. |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
