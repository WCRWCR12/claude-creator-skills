# Video Editing pack (8 free Claude skills)

Raw clip to finished reel: tight cuts, word-by-word captions, voiceover direction, local text-to-speech, sounds, and a video editor Claude builds for you.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `reel-cutter` | Cuts a raw talking-to-camera video into a tight reel. |
| `caption-sync` | Burns word-by-word captions into a video. |
| `instagram-edit` | Write and edit talking-head Instagram Reels and TikToks. |
| `anti-slop-ai-video-editing` | Five rules for editing short-form videos with Claude without the output looking like AI slop (captions, imagery, image placement, cuts, motion… |
| `live-editable-video-editor` | Build a lightweight video editor with Claude so a creator can tweak captions, stickers and audio live instead of describing changes in chat and… |
| `vo-delivery-direction` | Direct a voiceover so it sounds like a person talking, not an AI reading. |
| `voice-studio-local-tts` | Run open-source text-to-speech or voice cloning locally for faceless reel narration at no per-generation cost. |
| `trending-sounds` | Find the sounds Instagram Reels are using right now (trending audio, viral original audio, TikTok crossovers, evergreen meme sounds, SFX and… |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
