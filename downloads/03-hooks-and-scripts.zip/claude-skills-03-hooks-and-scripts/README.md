# Hooks and Scripts pack (8 free Claude skills)

Hooks written seven ways and tested, 100 hook formulas, and scripts for Reels and TikTok that hold attention to the end.

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

| Skill | What it does |
|---|---|
| `hook-writer` | the opening that earns attention — for any social content: a caption's first line, a video's first three seconds, a carousel cover slide, a thread… |
| `viral-hooks` | Generate 3 scroll-stopping hook variants for short-form video scripts (Reels, TikTok, YouTube, LinkedIn, X). |
| `hook-virality-check` | Compare several hook variants of one reel before posting, pick the winner, and find the drop-off point to re-edit. |
| `reels-script` | a native, sound-off-first short-video script optimized for Instagram's discovery engine, built around a 3-second hook, watch-through, and sends (DM… |
| `tiktok-script` | a native, sound-aware short-video script optimized for TikTok's discovery engine (the FYP), built around a brutal 1-second hook, watch-time, and… |
| `scriptwriting-methodology` | Direct response copywriting frameworks for video scripts. |
| `content-principles` | The psychology behind short-form content that holds attention. |
| `illusion-of-novelty` | A four-step storytelling framework (new reveal, contrast framing, urgency, bullseye proof) for making any topic feel fresh and addictive in… |

All packs and the full guide: https://github.com/WCRWCR12/claude-creator-skills
