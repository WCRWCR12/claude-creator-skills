# ULTRA: all 59 free Claude skills

Install: open the Claude desktop app, Code tab, drag this whole folder into the chat and say **"install these skills"**.

Full list and guide: https://github.com/WCRWCR12/claude-creator-skills
